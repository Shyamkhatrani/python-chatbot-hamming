def encode(data_bits):
    """
    Encode 4 bits of data using (7,4) Hamming code.
    """
    assert len(data_bits) == 4, "Data bits should be 4 bits long"

    # Calculate parity bits
    p1 = data_bits[0] ^ data_bits[1] ^ data_bits[3]
    p2 = data_bits[0] ^ data_bits[2] ^ data_bits[3]
    p3 = data_bits[1] ^ data_bits[2] ^ data_bits[3]

    # Construct the 7-bit Hamming code
    hamming_code = [
        p1,  # parity bit 1
        p2,  # parity bit 2
        data_bits[0],  # data bit 1
        p3,  # parity bit 3
        data_bits[1],  # data bit 2
        data_bits[2],  # data bit 3
        data_bits[3]   # data bit 4
    ]

    return hamming_code

def decode(hamming_code):
    """
    Decode the 7-bit Hamming code and correct single-bit errors.
    """
    assert len(hamming_code) == 7, "Hamming code should be 7 bits long"

    # Extract parity bits
    p1, p2, d1, p3, d2, d3, d4 = hamming_code

    # Calculate syndromes
    s1 = p1 ^ d1 ^ d2 ^ d4
    s2 = p2 ^ d1 ^ d3 ^ d4
    s3 = p3 ^ d2 ^ d3 ^ d4

    # Error position
    error_pos = s1 * 1 + s2 * 2 + s3 * 4

    if error_pos:
        print(f"Error detected at position {error_pos}. Correcting the error.")
        hamming_code[error_pos - 1] ^= 1  # Correct the error

    # Extract the data bits
    d1, d2, d3, d4 = hamming_code[2], hamming_code[4], hamming_code[5], hamming_code[6]

    return [d1, d2, d3, d4]

# Example Usage
data_bits = [1, 0, 1, 0]  # 4-bit data
encoded = encode(data_bits)
print(f"Encoded Hamming Code: {encoded}")

# Simulate an error for demonstration (optional)
encoded[3] ^= 1  # Introduce an error

decoded = decode(encoded)
print(f"Decoded Data Bits: {decoded}")
