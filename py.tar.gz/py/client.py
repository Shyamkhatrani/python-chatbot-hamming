import socket
import threading

# Function to receive messages from the server
def receive_messages(sock):
    while True:
        try:
            message = sock.recv(1024).decode('utf-8')
            if message:
                print(f"Received: {message}")
            else:
                break
        except ConnectionResetError:
            break
    sock.close()

# Connect to the server
server_ip = '127.0.0.1'  # Change this to your server's IP address
server_port = 12345

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((server_ip, server_port))

# Start a thread to receive messages
receive_thread = threading.Thread(target=receive_messages, args=(sock,))
receive_thread.start()

# Main loop to send messages
while True:
    message = input("Enter message: ")
    if message:
        sock.send(message.encode('utf-8'))
